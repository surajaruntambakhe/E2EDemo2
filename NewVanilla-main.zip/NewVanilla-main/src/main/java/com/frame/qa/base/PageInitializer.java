package com.frame.qa.base;

public class PageInitializer extends BrowserFactory {

}
