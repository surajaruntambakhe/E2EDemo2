package com.frame.qa.webpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.frame.qa.wrappers.BaseMethod;

public class HBSO_Page extends BaseMethod{

	
	@FindBy(xpath = "//header[@class='online-header site-header noindex white-bg sticky-header-cloned']//div/a[text()='Courses']")
			WebElement courseesLnk;
			@FindBy(xpath = "//a[@aria-label='Business Analytics']")
			WebElement businessAnalyticsCourseName;
			@FindBy(xpath = "//a[text()='Explore All Courses']")
			WebElement exploreAllCoursesLnk;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;
//			@FindBy(xpath = "")
//			WebElement womenLabel;

	
	public HBSO_Page() {
		PageFactory.initElements(driver_rw, this );
	}
	
	
	public void checkCourseDetails() throws Exception {
		waitForPageLoad();
		click(exploreAllCoursesLnk);
		Wait(2000);
//		click(businessAnalyticsCourseName);
//		Wait(2000);
		
	}
	
	
}
