package com.frame.qa.sampleTestcases;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;

public class Abc {

	
	public static void main(String[] args) throws IOException {
		
			//System.out.println(System.getProperty("user.dir"));
//			
//			File f=new File("pom.xml");
//			System.out.println(f.getCanonicalPath());
		
		
		
		
		// System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");
			//  WebDriverManager.chromedriver().setup();
//			  driver.close();
		
		 ChromeDriver  driver = new ChromeDriver();
			 DevTools devTools = driver.getDevTools();
			driver.get("https://www.amazon.in/");
			driver.manage().window().maximize();
		}
	

	
}
